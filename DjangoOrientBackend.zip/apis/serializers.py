from django.db import models
from django.db.models import fields
from rest_framework import serializers
from .models import Products,Variants,Images
class ProductsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Products
        fields = '__all__'
class VariantsSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Variants
        fields = '__all__'
class ImagesSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Images
        fields = '__all__'


