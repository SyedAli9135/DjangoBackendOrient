from django.contrib import admin
from .models import Products, Variants, Images
# Register your models here.
admin.site.register(Products)
admin.site.register(Variants)
admin.site.register(Images)
