from django.shortcuts import render
from rest_framework import viewsets
from .models import Products, Variants, Images
from .serializers import ProductsSerializer, VariantsSerializer, ImagesSerializer
# Create your views here.

class ProductsViewSet(viewsets.ModelViewSet):
    queryset = Products.objects.all().order_by('id')
    serializer_class = ProductsSerializer
class VariantsViewSet(viewsets.ModelViewSet):
    queryset = Variants.objects.all().order_by('product')
    serializer_class = VariantsSerializer
class ImagesViewSet(viewsets.ModelViewSet):
    queryset = Images.objects.all().order_by('products')
    serializer_class = ImagesSerializer

    