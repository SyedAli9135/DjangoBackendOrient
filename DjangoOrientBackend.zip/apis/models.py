
from django.db import models
from django.db.models.deletion import CASCADE


# Create your models here.

class Products(models.Model):
    title = models.CharField(max_length=100)
    text = models.CharField(max_length=100)
    image = models.ImageField(upload_to = 'ProductImages', blank=True)
    created = models.DateTimeField()
    updated = models.DateTimeField()
    def __str__(self):
        return str('%s: %s: %s' % (self.title, self.created, self.updated))

class Variants(models.Model):
    product = models.ForeignKey(Products,related_name='product', on_delete=CASCADE)
    created_time = models.ForeignKey(Products, related_name='created_at', on_delete=CASCADE)
    updated_time = models.ForeignKey(Products, related_name='updated_at', on_delete=CASCADE)
    price = models.IntegerField()
    sale_price = models.IntegerField()
    quantity  = models.IntegerField()
    Barcode = models.CharField(max_length=100)
    size = models.CharField(max_length=20)
   
    def __str__(self):
        return str(self.price)
class Images(models.Model):
    products = models.ForeignKey(Products,related_name='productref', on_delete=CASCADE, blank=True)
    created_timeref= models.ForeignKey(Products, related_name='producttimeref', on_delete=CASCADE)
    updated_timeref = models.ForeignKey(Products, related_name='updatetimeref', on_delete=CASCADE)
    attachment1 = models.ImageField(upload_to = 'Attachments', blank=True)
    attachment2 = models.ImageField(upload_to='Attachments', blank=True)
    position = models.IntegerField()
    def __str__(self):
        return str(self.position)



